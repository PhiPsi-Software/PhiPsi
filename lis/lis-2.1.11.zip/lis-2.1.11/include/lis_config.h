/* include/lis_config.h.  Generated from lis_config.h.in by configure.  */
/* include/lis_config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to dummy 'main' function (if any) required to link to the Fortran
   libraries. */
/* #undef F77_DUMMY_MAIN */

/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
#define F77_FUNC(name,NAME) name ## _

/* As F77_FUNC, but for C identifiers containing underscores. */
#define F77_FUNC_(name,NAME) name ## _

/* Define if F77 and FC dummy 'main' functions are identical. */
/* #undef FC_DUMMY_MAIN_EQ_F77 */

/* Define to 1 to enable quad precision operations using FMA. */
/* #undef HAS_FMA */

/* Define to 1 to enable x87 FPU. */
#define HAS_X87_FPU 1

/* Define to 1 if you have the <complex.h> header file. */
#define HAVE_COMPLEX_H 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the <quadmath.h> header file. */
#define HAVE_QUADMATH_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "lis"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "devel@ssisc.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "lis"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "lis 2.1.11"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "lis"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.1.11"

/* Test the size of a `double', as computed by sizeof. */
#define SIZEOF_DOUBLE 8

/* Test the size of a `float', as computed by sizeof. */
#define SIZEOF_FLOAT 4

/* Test the size of a `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* Test the size of a `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* Test the size of a `__float128', as computed by sizeof. */
#define SIZEOF_LONG_DOUBLE 16

/* Test the size of a `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* Test the size of a `size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 8

/* Test the size of a `void *', as computed by sizeof. */
#define SIZEOF_VOID_P 8

/* The size of '__float128', as computed by sizeof. */
#define SIZEOF___FLOAT128 16

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define to 1 to enable complex scalar operations. */
/* #undef USE_COMPLEX */

/* Define to 1 to enable quad precision operations using fast quad add. */
/* #undef USE_FAST_QUAD_ADD */

/* Define to 1 to enable quad precision operations using FMA and SSE2. */
/* #undef USE_FMA2_SSE2 */

/* Define to 1 to enable Fortran subroutines. */
#define USE_FORTRAN 1

/* Use MAIN__ macro with Fortran. */
/* #undef USE_MAIN__ */

/* Define to 1 to enable quad precision operations. */
/* #undef USE_QUAD_PRECISION */

/* Define to 1 to enable SA-AMG preconditioner. */
/* #undef USE_SAAMG */

/* Define to 1 to enable quad precision operations using SSE2. */
/* #undef USE_SSE2 */

/* Define to 1 to use vectorization. */
/* #undef USE_VEC_COMP */

/* Version number of package */
#define VERSION "2.1.11"

/* Define to empty if 'const' does not conform to ANSI C. */
/* #undef const */

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */
