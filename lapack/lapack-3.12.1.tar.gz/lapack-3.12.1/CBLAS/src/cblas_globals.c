   int CBLAS_CallFromC=0;
   int RowMajorStrg=0;
